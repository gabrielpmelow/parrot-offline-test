# API Reference

```{eval-rst}
.. automodule:: micropip
    :members:
    :undoc-members:
    :member-order: bysource
